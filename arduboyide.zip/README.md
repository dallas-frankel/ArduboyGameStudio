# arduboy IDE

## First time setup
```
# Setup windows build tools
npm install -g windows-build-tools
#  Install libraries
npm install
# Rebuild electron libraries
npm run rebuild
# Start the app
npm start
# Close App
#Rebuild
npm run rebuild
# Start the app again
npm start
```
